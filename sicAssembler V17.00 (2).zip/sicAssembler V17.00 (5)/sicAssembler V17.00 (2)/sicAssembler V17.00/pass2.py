
# Pass 2 : reads a intermediate_file that produced by pass 1 and generate the object file and listing file
#  *Listing file contains  source file with LOCCTR and object code for each line
#  *Object file contains all text records (H , T ,E).


#******************************************************************************************


def hex_to_decimal(hex_string):
    """Converts a hexadecimal string to a decimal integer."""
    return int(hex_string, 16)

from optable import optab 


def generate_object_program(intermediate_file, start_address, program_length, optab, symtab, output_file):
    object_file = open(output_file, "w")
    intermediate = open(intermediate_file, "r")

    addrlist = []
    l = []

    # Read lines from intermediate file
    op = '' 
    print(optab)
    for line in intermediate:
        parts = line.strip().split()
        if len(parts) == 0 : 
            address = '' 
        else : 
            address = parts[0][2:]  # Extract address
        addrlist.append(address)

        if len(parts) == 0  : 
            continue
        label = parts[0]
       
        opcode = parts[1]
        operand = parts[2] if len(parts) > 3 else ""

        if opcode == "START":
            # Write Header record
            object_file.write(f"H^{label}^00{start_address}^00{program_length}\n")

        elif opcode == "END":
            # Write End record
            object_file.write(f"E^{start_address}\n")

        else:
            
            if opcode in optab:
                # Process instructions using OPTAB
                if opcode == "RSUB":
                    op = optab[opcode] + "0000"
                elif operand in symtab:
                    op = optab[opcode] + str(symtab[operand])
                else:
                    op = optab[opcode]
                # print(op , opcode) 
                # print(opcode)
                # print(optab)
                l.append(op)

            elif opcode == "WORD":
                # Handle WORD directive
                word_value = int(operand)
                op = hex(word_value)[2:].upper().zfill(6)
                l.append(op)

            elif opcode == "BYTE":
                # Handle BYTE directive
                if operand.startswith("X'") or operand.startswith("x'"):
                    # Hexadecimal constant
                    hex_value = operand[2:-1]
                    op = hex_value.upper()
                elif operand.startswith("C'") or operand.startswith("c'"):
                    # Character constant
                    char_value = operand[2:-1]
                    op = "".join([hex(ord(char))[2:].upper() for char in char_value])

                l.append(op)

            else:
                l.append("-")
    # Write Text records
    i = 0
    while i < len(l):
        if i == 0:
            STRT = addrlist[1]
        else:
            STRT = addrlist[i]

        cnt = 0
        last_pos = object_file.tell()

        if i < len(l) and l[i] != "-":
            object_file.write(f"\nT^{STRT}^")
            last_pos = object_file.tell()
            object_file.write("  ^")

        while i < len(l) and l[i] != "-" and cnt < 10:
            object_file.write(l[i])
            cnt += 1
            i += 1

        object_file.seek(last_pos)
        tempaddr = str(addrlist[i]) #str(hex(int(addrlist[i], 16) - int(STRT, 16)))
        straddr = tempaddr[2:4]
        object_file.write(straddr)
        object_file.seek(0, 2)
        i += 1

    object_file.close()
    intermediate.close()
    print(l)
import json 
# Usage example:
def read_json_file(file_path):
    """
    Reads a JSON file and returns a list of dictionaries containing its content.

    Args:
        file_path (str): The path to the JSON file.

    Returns:
        list: A list of dictionaries containing the JSON data.
    """
    try:
        with open(file_path, "r") as json_file:
            data = json.load(json_file)
            return data
    except FileNotFoundError:
        print("File not found:", file_path)
        return []
    except json.JSONDecodeError:
        print("Error decoding JSON from file:", file_path)
        return []
    
memory_labels = read_json_file('symbol_table')

generate_object_program("intermediate.mdt", 1000, '107a', optab, memory_labels, "ObjectProgram.obj")