#Mohammad Anwar Salameen
#201156
#Computer Systems Engineering

# in pass 1 : Read the source_file.asm and OPTAB.txt and produce a intermediate.mdt file and print SYMTAB in screen 
# *intermediate_file contain a source_file.asm with LOCCTR (Address) for each line , Program_length and Program Name
# *SYMTAB : contain all symbols with LOCCTR.

#**********************************************************************************

import json

def write_json_file(data , file_path) : 
    # Write JSON data to file
    with open(file_path, "w") as json_file:
        json.dump(data, json_file)
    print("JSON data has been written to", file_path)

def hex_to_decimal(hex_string):
    decimal_value = int(hex_string, 16)
    return decimal_value

def pass1(source_file, optab_file, intermediate_file):
    SYMTAB = {}  # Symbol table
    LOCCTR = 0   # Location counter
    starting_address = 0  # Starting address
    program_length = 0  # Program length
    prg_name = ""  # Program name
    error_flag = False  # Error flag
    literal_table = {}  # Literal table
    

    # Load OPTAB
    OPTAB = {}
    with open(optab_file, 'r') as optab_file:
        for line in optab_file:
            opcode, _ = line.strip().split()
            OPTAB[opcode] = 3  # Default instruction length

    # List of directives
    directives = ["START", "END", "BYTE", "WORD", "RESB", "RESW", "BASE", "LTORG"]

    with open(source_file, 'r') as infile, open(intermediate_file, 'w') as outfile:
        

        for line in infile:
            line = line.strip()  # Remove leading/trailing whitespace
            parts = line.split()  # Split line into parts

            # Check if line is empty or a comment
            if not line or line.startswith('.'):
                continue

            # Read first input line
            if not starting_address:
                if parts[1] == 'START':
                    prg_name = parts[0]
                    starting_address = parts[2]
                    starting_address = hex_to_decimal(starting_address)
                    LOCCTR = starting_address

                    outfile.write(f"{str(hex(LOCCTR))[2:]}  {line}\n")  # Write line to intermediate file
                    continue
                else:
                    LOCCTR = 0

            # Process labels
            if (parts[0] in OPTAB):
                opcode = parts[0]
            else : 
                    label = parts[0]
                    if ':' in label:  # Check if label contains a colon
                        label = label.split(':')[0]  # Remove colon if present
                    if label in SYMTAB:
                        error_flag = True
                        print("Error: Duplicate symbol")
                        break
                    if parts[1] != 'END':  # Only add labels with instructions to SYMTAB
                        SYMTAB[label] = LOCCTR

            # Process instructions and directives
            if  opcode != parts[0] :
                opcode = parts[1]
            if opcode != 'END':
                outfile.write(f"{LOCCTR:04X}  {line}\n")  # Write line to intermediate file
            # Search OPTAB for OPCODE
            if opcode in OPTAB:
                LOCCTR += OPTAB[opcode]
            elif opcode == 'WORD':
                LOCCTR += 3
            elif opcode == 'RESW':
                LOCCTR += 3 * int(parts[2])
            elif opcode == 'RESB':
                LOCCTR += int(parts[2])
            elif opcode == 'BYTE':
                operand = parts[2]
                if operand.startswith('X'):
                    LOCCTR += (len(operand) - 3) // 2
                elif operand.startswith('C'):
                    LOCCTR += len(operand) - 3
            elif opcode == "LTORG":
                for literal in literal_table:
                    literal_table[literal][1] = hex(LOCCTR)[2:]
                    outfile.write(f"{LOCCTR:04X}  *       ={literal}\n")
                    LOCCTR += len(literal_table[literal][0]) // 2
                literal_table = {}
            else:
                error_flag = True
                print("Error: Invalid operation code")
                break

        # Print symbol table to screen
        print("\nSymbol Table (SYMTAB):")
        for symbol, loc in SYMTAB.items():
            print(f"{loc:04X}  {symbol}")
            

        # Write PRGLTH and PRGNAME to intermediate file
        program_length = str(hex(LOCCTR - starting_address))[2:]
        outfile.write(f"\nPRGLTH: {program_length}\n")
        outfile.write(f"PRGNAME: {prg_name}\n")
        
        # Check for error
        if error_flag:
            print("Pass 1 failed due to errors.")

    write_json_file(SYMTAB , 'symbol_table')

# Sample usage
pass1("source_file.asm", "OPTAB.txt", "intermediate.mdt")
































